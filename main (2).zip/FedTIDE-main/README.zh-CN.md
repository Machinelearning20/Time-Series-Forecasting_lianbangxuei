# 🚀 FedTIDE

<div align="center">

**Federated Adaptation of Time-Series Foundation Models under Spatio-Temporal Drift**

**面向时空漂移的时序基础模型联邦自适应微调**

[English](README.md) | **中文**

<img src="https://img.shields.io/badge/Python-3.10-blue.svg?logo=python&logoColor=white" alt="Python 3.10">
<img src="https://img.shields.io/badge/PyTorch-2.0%2B-ee4c2c.svg?logo=pytorch&logoColor=white" alt="PyTorch">
<img src="https://img.shields.io/badge/License-MIT-green.svg" alt="License">
<img src="https://img.shields.io/badge/Venue-ICASSP%202027-orange.svg" alt="ICASSP 2027">

*赵志刚 · 李传涛 · 霍继东 · 王春晓 · 高龙翔*

</div>

---

## 📌 TL;DR

工业传感器流是私有、碎片化、且**时空耦合漂移**的：跨机构采样率/通道/工况差异巨大（**空间非 IID**），机构内部又因设备老化、工况切换、季节效应随时间演化（**时间概念漂移**）。现有联邦方法"固定轮次 + 样本量加权"聚合 LoRA 适配器，忽略时序模式相似性与漂移事件，导致陈旧/漂移更新持续污染全局适配器。

**FedTIDE** 同时重设计"**怎么聚合**"与"**何时聚合**"：

| 组件 | 作用 | 一句话 |
|---|---|---|
| 🧠 **TPA**（时序模式感知加权） | 怎么聚合 | 用"时序签名相似度 × 更新方向一致性 × 新鲜度"替代样本量加权 |
| ⏱️ **DES**（漂移感知事件驱动调度） | 何时聚合 | 用 ADWIN/MMD 检测漂移，漂移触发局部聚合，替代固定轮次 |
| 🔀 **Product-space 融合** | 融合去失真 | 在 B·A 乘积空间加权，截断 SVD 回秩 r，避免分别平均 LoRA 因子的失真 |

在 C-MAPSS + FedCMAPSS 协议的联邦 RUL 任务上，FedTIDE 相对最强传统联邦基线：**RMSE ↓14.2% / NASA Score ↓23.0%**（域偏移任务），且**聚合事件数 ↓44%**（56 vs 100）。

---

## ✨ 亮点

- 🧩 **模型无关的漂移信号** — 漂移检测跑在冻结 backbone 的"一步预测残差 + 嵌入统计"上，**不依赖回归头**，对无标签流式数据也能工作。
- 📡 **亚 KB 级签名** — 时序签名只有几百个 float，基于冻结特征计算，**不泄露原始序列**（隐私友好）。
- 🔒 **陈旧客户端隔离** — 漂移客户端被隔离出参与集 `S^t`，把污染窗口从"无限长"压缩到 `O(κ⁻¹)` 个事件。
- 🏭 **原生时空漂移** — 用 C-MAPSS 的 FD002/004（6 工况切换 + 退化）做天然漂移，无需人工注入。
- 📉 **负迁移抑制** — 余弦方向门控 `ReLU(cos(Δ_k, Δ̄))` 直接清零与共识冲突的更新。

---

## 🧠 方法

### 双时间尺度闭环

```
  ┌──────────── 快尺度（客户端）────────────┐        ┌────────── 慢尺度（服务器）──────────┐
  │ 流式数据 → 冻结 backbone + 全局适配器    │        │ 维护共识签名 s̄                     │
  │      → 漂移监测（ADWIN/MMD）            │  报警  │ 累积漂移证据 → 触发 Eq(4)            │
  │      → 局部适应 E 步                    │ ────▶ │ 选出参与集 S^t = {k : a_k = 1}       │
  │      → 上传 (Δ_k, s_k, m_k)             │ ◀──── │ TPA 加权 → product 融合 → 广播       │
  └────────────────────────────────────────┘        └────────────────────────────────────┘
```

### 🧠 TPA — 时序模式感知加权

时序签名（冻结特征，几百维）：

$$\mathbf{s}_k^t = \Big[\;\mu\!\big(E_{\theta^\star}(\mathcal{B}_k^t)\big),\;\phi_{\text{spec}}(\mathcal{B}_k^t),\;\phi_{\text{acf}}(\mathcal{B}_k^t)\;\Big]$$

权重构造（四因子相乘，再归一化）：

$$w_k^t = \underbrace{n_k^{\alpha}}_{\text{数据量}}\cdot\underbrace{\exp\!\big(-\tfrac{d_{\text{MMD}}(s_k^t,\bar{s}^t)}{\tau}\big)}_{\text{时序模式对齐}}\cdot\underbrace{\rho^{\Delta t_k}}_{\text{新鲜度}}\cdot\underbrace{\mathrm{ReLU}\!\big(\cos(\Delta_k^t,\bar{\Delta}^{t})\big)}_{\text{冲突门控}}$$

### ⏱️ DES — 漂移感知事件驱动调度

- **客户端检测**：ADWIN 作用于两条冻结 backbone 信号流（一步预测残差 + 嵌入原型位移/频谱带能量）；可选 MMD 两样本检验佐证并估计漂移量级 `m_k^t`。
- **服务器触发**（漂移证据超预算 或 最大陈旧度超 `T_max`）：

$$u^t = \mathbb{1}\Big\{\textstyle\sum_k m_k^t a_k^t \ge \kappa \;\lor\; \max_k \Delta t_k \ge T_{\max}\Big\}$$

- **参与集**：`S^t = {k : a_k^t = 1}`；沉默超过 `T_q` 轮的客户端被隔离，直到签名重新对齐共识。

### 🔀 Product-space 融合

设 `P^g = B^g A^g`、`P_k^t = B_k^t A_k^t`，在乘积空间融合后回秩 r：

$$\widetilde{P} = P^g + \eta\sum_{k\in S^t}\hat w_k^t\,(P_k^t - P^g)\;\xrightarrow{\text{truncated SVD}}\; (B^g, A^g)$$

---

## 📊 实验结果

> 协议：NASA C-MAPSS + FedCMAPSS 联邦 RUL 划分（5 task × 10 随机划分，取均值）。
> 指标：RMSE (cycles) / NASA Score。**越小越好**；`σ≈X` 表示该格 Score 标准差过大（不稳定）。

**表 1 · 主表（FedTIDE vs 传统联邦基线，均 LSTM）**

| Method | Task A (IID) | Task B (域偏移) | Task C (标签偏斜) | Task D (特征偏斜) | Task E (稀缺) |
|---|---|---|---|---|---|
| FedAvg | 17.66 / 0.99 | 21.14 / 9.85 | 29.48 / 38.26 | 14.12 / 4.23 | 27.30 / 5.42 |
| SCAFFOLD | 17.36 / 0.81 | 18.42 / 7.06 | 27.31 / 31.73 | 12.58 / 3.85 | 28.92 / 9.63 |
| FedDyn | 23.45 / 2.38 | 40.83 / σ≈36 | 39.92 / 15.01 | 24.67 / 14.51 | 34.41 / 32.86 |
| FedCross | 18.81 / 1.06 | 16.43 / 5.35 | 17.28 / 1.44 | 12.28 / 3.52 | 28.15 / 7.83 |
| **FedTIDE (ours)** | **15.84 / 0.89** | **14.09 / 4.12** | **15.27 / 1.02** | **10.08 / 2.63** | **28.75 / 8.51** |

**表 2 · 消融（同 backbone，Tasks B/C/D，RMSE + 平均 Events）**

| Method | Task B | Task C | Task D | Events |
|---|---|---|---|---|
| FedAvg-LoRA (no TPA, no DES) | 16.07 | 17.23 | 12.65 | 100 |
| FedTIDE w/o TPA | 14.96 | 16.12 | 12.07 | 56 |
| FedTIDE w/o DES | 14.09 | 15.27 | 10.08 | 100 |
| **FedTIDE (full)** | **14.09** | **15.27** | **10.08** | **56** |

📌 **核心结论**
- 异质任务（B/C/D）上 FedTIDE 全面最优：相对最强基线 **RMSE ↓14.2% / 11.6% / 17.9%**，**NASA ↓23.0% / 29.2% / 25.3%**。
- IID（Task A）下不退化：RMSE 15.84 低于 SCAFFOLD 17.36，NASA 0.89 与最优 0.81 可比。
- 事件驱动省通信：**56 事件 vs 固定 100（↓44%）**，精度持平（w/o DES 与 full 的 RMSE 相同）。
- 极端稀缺（Task E）下仍具竞争力但不超 FedAvg。

---

## 🗂️ 仓库结构

```
FedTIDE_Code/
├── README.md                  # 本文件（英文）
├── README.zh-CN.md            # 中文版
├── requirements.txt           # 依赖
├── config/
│   └── default.yaml           # 全部超参（TPA/DES/LoRA/训练）
├── scripts/
│   ├── download_cmapss.sh     # 下载 C-MAPSS (NASA PCoE)
│   └── run_task.sh            # 单 task 复现入口
├── src/fedtide/
│   ├── data.py                # C-MAPSS 加载 · 窗口化 · RUL 标注 · FedCMAPSS 5-task 划分
│   ├── model.py               # 冻结 Chronos-2 编码器 + MLP 头 + LoRA 注入
│   ├── lora.py                # LoRA A/B · product-space 融合 · 截断 SVD
│   ├── tpa.py                 # 时序签名 + MMD + 四因子权重
│   ├── des.py                 # ADWIN/MMD 漂移检测 · 事件触发 Eq(4) · 隔离
│   ├── fed.py                 # Client（局部适应/报告） + Server（共识签名/融合）
│   ├── metrics.py             # RMSE + NASA Score
│   └── train.py               # 主入口：静态 FedCMAPSS 协议
└── experiments/               # 每 task 的 config + 结果 dump
```

---

## ⚙️ 安装

```bash
git clone <repo-url> && cd FedTIDE_Code
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```

> ⚠️ 需要能访问 HuggingFace 以下载 Chronos-2 预训练权重（或提前 `huggingface-cli download` 缓存）。

---

## 📦 数据准备

1. **C-MAPSS**：从 [NASA PCoE](https://www.nasa.gov/intelligent-systems-division/discovery-and-systems-health/pcoe/pcoe-data-set-repository) 下载 `CMAPSSData.zip`（含 FD001–FD004 的 `train_FD00X.txt` / `test_FD00X.txt` / `RUL_FD00X.txt`）。
2. **联邦划分**：直接采用 [FedCMAPSS](https://github.com/perceivelab/FedCMAPSS) 的 5-task 划分与评测协议（Task A–E）。
3. 放置到 `data/` 并在 `config/default.yaml` 指定路径。

```bash
bash scripts/download_cmapss.sh   # 自动下载并解压
```

---

## ▶️ 使用

**复现单 task（如 Task B 域偏移）**

```bash
python src/fedtide/train.py --task B --config config/default.yaml
```

**完整五 task**

```bash
for t in A B C D E; do bash scripts/run_task.sh $t; done
```

**消融（关掉某个组件）**

```bash
python src/fedtide/train.py --task D --ablate no_tpa   # 或 no_des / no_gate
```

---

## 🔧 关键超参（`config/default.yaml`）

| 参数 | 含义 | 默认 |
|---|---|---|
| `lora.rank` | LoRA 秩 r | 8 |
| `tpa.alpha` | 数据量因子指数 n^α | 0.5 |
| `tpa.tau` | MMD 温度 | 1.0 |
| `tpa.rho` | 新鲜度衰减 ρ | 0.9 |
| `des.kappa` | 漂移证据预算 κ | tune |
| `des.t_max` | 最大陈旧度（强制聚合） | tune |
| `des.t_q` | 隔离阈值（轮） | tune |
| `des.local_steps` | 报警后局部适应步数 E | 5 |
| `fuse.eta` | 融合步长 η | 1.0 |
| `fuse.rank` | 回投影秩 r（= LoRA rank） | 8 |

---

## 📖 引用

```bibtex
@inproceedings{zhao2026fedtide,
  title   = {{FedTIDE}: Federated Adaptation of Time-Series Foundation Models
             under Spatio-Temporal Drift},
  author  = {Zhao, Zhigang and Li, Chuantao and Huo, Jidong and
             Wang, Chunxiao and Gao, Longxiang},
  booktitle = {IEEE International Conference on Acoustics, Speech and
               Signal Processing (ICASSP)},
  year    = {2027}
}
```

---

## 📄 License

MIT License，详见 `LICENSE`。

## 🙏 致谢

本工作构建于 [Chronos-2](https://github.com/amazon-science/chronos-forecasting)、[FedCMAPSS](https://github.com/perceivelab/FedCMAPSS) 以及 LoRA / ADWIN / MMD 系列工作之上。
