# 🚀 FedTIDE

<div align="center">

**Federated Adaptation of Time-Series Foundation Models under Spatio-Temporal Drift**

**English** | [中文](README.zh-CN.md)

<img src="https://img.shields.io/badge/Python-3.10-blue.svg?logo=python&logoColor=white" alt="Python 3.10">
<img src="https://img.shields.io/badge/PyTorch-2.0%2B-ee4c2c.svg?logo=pytorch&logoColor=white" alt="PyTorch">
<img src="https://img.shields.io/badge/License-MIT-green.svg" alt="License">
<img src="https://img.shields.io/badge/Venue-ICASSP%202027-orange.svg" alt="ICASSP 2027">

*Zhigang Zhao · Chuantao Li · Jidong Huo · Chunxiao Wang · Longxiang Gao*

</div>

---

## 📌 TL;DR

Industrial sensor streams are private, fragmented, and subject to **spatio-temporally coupled drift**: across organizations, sampling rates, channel configurations, and operating regimes differ substantially (**spatial non-IID**), while within each organization the data distribution evolves over time due to equipment aging, operating-condition switches, and seasonal effects (**temporal concept drift**). Existing federated methods aggregate LoRA adapter updates at fixed rounds with sample-size weighting, ignoring temporal-pattern similarity and drift events, so stale or shifted updates progressively contaminate the global adapter.

**FedTIDE** co-designs *how* and *when* adapter updates are aggregated:

| Component | Role | In one line |
|---|---|---|
| 🧠 **TPA** (Temporal-Pattern-Aware Weighting) | *how* to aggregate | Replaces sample-size weighting with temporal-signature similarity × update-direction consistency × freshness |
| ⏱️ **DES** (Drift-Aware Event-Driven Scheduling) | *when* to aggregate | Detects drift with ADWIN/MMD and triggers drift-based partial aggregation instead of fixed rounds |
| 🔀 **Product-space Fusion** | distortion-free fusion | Fuses in the B·A product space and projects back to rank r via truncated SVD, avoiding the distortion of averaging LoRA factors separately |

On the C-MAPSS benchmark under the FedCMAPSS federated RUL protocol, FedTIDE reduces **RMSE by 14.2%** and **NASA Score by 23.0%** over the strongest traditional federated baseline on the domain-shift task, while cutting aggregation events by **44%** (56 vs 100).

---

## ✨ Highlights

- 🧩 **Model-agnostic drift signals** — drift detection runs on frozen-backbone signals (one-step prediction residuals + embedding statistics), independent of the regression head, so it also works on unlabeled streaming data.
- 📡 **Sub-KB signatures** — the temporal signature is a few hundred floats computed on frozen features and reveals no raw series (privacy-friendly).
- 🔒 **Stale-client quarantine** — drifted clients are quarantined from the participant set `S^t`, compressing the contamination window from unbounded to `O(κ⁻¹)` events.
- 🏭 **Native spatio-temporal drift** — C-MAPSS FD002/004 (six operating conditions + degradation) serve as natural drift, no synthetic injection needed.
- 📉 **Negative-transfer suppression** — the cosine conflict gate `ReLU(cos(Δ_k, Δ̄))` zeroes out updates that conflict with the consensus.

---

## 🧠 Method

### Dual time-scale loop

```
  ┌────────── Fast scale (client) ──────────┐        ┌────────── Slow scale (server) ──────────┐
  │ stream → frozen backbone + global adapter│       │ maintain consensus signature s̄         │
  │      → drift monitor (ADWIN/MMD)         │ alarm │ accumulate drift evidence → fire Eq(4)  │
  │      → E local adaptation steps          │ ────▶ │ select S^t = {k : a_k = 1}              │
  │      → upload (Δ_k, s_k, m_k)            │ ◀──── │ TPA weights → product fusion → broadcast │
  └──────────────────────────────────────────┘        └─────────────────────────────────────────┘
```

### 🧠 TPA — Temporal-Pattern-Aware Weighting

Temporal signature (frozen features, a few hundred dims):

$$\mathbf{s}_k^t = \Big[\;\mu\!\big(E_{\theta^\star}(\mathcal{B}_k^t)\big),\;\phi_{\text{spec}}(\mathcal{B}_k^t),\;\phi_{\text{acf}}(\mathcal{B}_k^t)\;\Big]$$

Weight construction (four factors, then normalized):

$$w_k^t = \underbrace{n_k^{\alpha}}_{\text{data volume}}\cdot\underbrace{\exp\!\big(-\tfrac{d_{\text{MMD}}(s_k^t,\bar{s}^t)}{\tau}\big)}_{\text{temporal-pattern alignment}}\cdot\underbrace{\rho^{\Delta t_k}}_{\text{freshness}}\cdot\underbrace{\mathrm{ReLU}\!\big(\cos(\Delta_k^t,\bar{\Delta}^{t})\big)}_{\text{conflict gate}}$$

### ⏱️ DES — Drift-Aware Event-Driven Scheduling

- **Client-side detection**: ADWIN over two frozen-backbone signal streams (one-step prediction residual + prototype displacement / spectral-band energy); an optional MMD two-sample test corroborates the alarm and estimates the drift magnitude `m_k^t`.
- **Server-side trigger** (drift evidence over budget, or max staleness over `T_max`):

$$u^t = \mathbb{1}\Big\{\textstyle\sum_k m_k^t a_k^t \ge \kappa \;\lor\; \max_k \Delta t_k \ge T_{\max}\Big\}$$

- **Participant set**: `S^t = {k : a_k^t = 1}`; clients silent for more than `T_q` rounds are quarantined until their signature re-aligns with the consensus.

### 🔀 Product-space Fusion

Let `P^g = B^g A^g` and `P_k^t = B_k^t A_k^t`. Fuse in the product space, then project back to rank r:

$$\widetilde{P} = P^g + \eta\sum_{k\in S^t}\hat w_k^t\,(P_k^t - P^g)\;\xrightarrow{\text{truncated SVD}}\; (B^g, A^g)$$

---

## 📊 Results

> Protocol: NASA C-MAPSS + FedCMAPSS federated RUL partition (5 tasks × 10 random splits, mean reported).
> Metrics: RMSE (cycles) / NASA Score. **Lower is better**; `σ≈X` denotes an unstable Score cell (std ≈ X).

**Table 1 · Main results (FedTIDE vs. traditional federated baselines, all LSTM)**

| Method | Task A (IID) | Task B (domain shift) | Task C (label skew) | Task D (feature skew) | Task E (scarcity) |
|---|---|---|---|---|---|
| FedAvg | 17.66 / 0.99 | 21.14 / 9.85 | 29.48 / 38.26 | 14.12 / 4.23 | 27.30 / 5.42 |
| SCAFFOLD | 17.36 / 0.81 | 18.42 / 7.06 | 27.31 / 31.73 | 12.58 / 3.85 | 28.92 / 9.63 |
| FedDyn | 23.45 / 2.38 | 40.83 / σ≈36 | 39.92 / 15.01 | 24.67 / 14.51 | 34.41 / 32.86 |
| FedCross | 18.81 / 1.06 | 16.43 / 5.35 | 17.28 / 1.44 | 12.28 / 3.52 | 28.15 / 7.83 |
| **FedTIDE (ours)** | **15.84 / 0.89** | **14.09 / 4.12** | **15.27 / 1.02** | **10.08 / 2.63** | **28.75 / 8.51** |

**Table 2 · Ablation (same backbone, Tasks B/C/D, RMSE + average Events)**

| Method | Task B | Task C | Task D | Events |
|---|---|---|---|---|
| FedAvg-LoRA (no TPA, no DES) | 16.07 | 17.23 | 12.65 | 100 |
| FedTIDE w/o TPA | 14.96 | 16.12 | 12.07 | 56 |
| FedTIDE w/o DES | 14.09 | 15.27 | 10.08 | 100 |
| **FedTIDE (full)** | **14.09** | **15.27** | **10.08** | **56** |

📌 **Key takeaways**
- On the heterogeneity tasks (B/C/D), FedTIDE is best across the board: **RMSE ↓14.2% / 11.6% / 17.9%** and **NASA ↓23.0% / 29.2% / 25.3%** over the strongest baseline.
- No degradation on IID (Task A): RMSE 15.84 vs. SCAFFOLD 17.36, NASA 0.89 vs. best 0.81.
- Event-driven communication: **56 events vs. 100 fixed (↓44%)** at matched accuracy (w/o DES equals full on RMSE).
- Under extreme scarcity (Task E), FedTIDE stays competitive but does not surpass FedAvg.

---

## 🗂️ Repository Structure

```
FedTIDE_Code/
├── README.md                  # this file (English)
├── README.zh-CN.md            # 中文版
├── requirements.txt           # dependencies
├── config/
│   └── default.yaml           # all hyperparameters (TPA/DES/LoRA/training)
├── scripts/
│   ├── download_cmapss.sh     # download C-MAPSS (NASA PCoE)
│   └── run_task.sh            # reproduce a single task
├── src/fedtide/
│   ├── data.py                # C-MAPSS loading · windowing · RUL labeling · FedCMAPSS 5-task partition
│   ├── model.py               # frozen Chronos-2 encoder + MLP head + LoRA injection
│   ├── lora.py                # LoRA A/B · product-space fusion · truncated SVD
│   ├── tpa.py                 # temporal signature + MMD + 4-factor weighting
│   ├── des.py                 # ADWIN/MMD drift detection · event trigger Eq(4) · quarantine
│   ├── fed.py                 # Client (local adapt/report) + Server (consensus/fusion)
│   ├── metrics.py             # RMSE + NASA Score
│   └── train.py               # entry point: static FedCMAPSS protocol
└── experiments/               # per-task configs + result dumps
```

---

## ⚙️ Installation

```bash
git clone <repo-url> && cd FedTIDE_Code
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```

> ⚠️ HuggingFace access is required to download Chronos-2 pretrained weights (or cache them in advance via `huggingface-cli download`).

---

## 📦 Data Preparation

1. **C-MAPSS**: download `CMAPSSData.zip` (FD001–FD004: `train_FD00X.txt` / `test_FD00X.txt` / `RUL_FD00X.txt`) from [NASA PCoE](https://www.nasa.gov/intelligent-systems-division/discovery-and-systems-health/pcoe/pcoe-data-set-repository).
2. **Federated partition**: adopt the 5-task split and evaluation protocol of [FedCMAPSS](https://github.com/perceivelab/FedCMAPSS) (Task A–E).
3. Put them under `data/` and set the paths in `config/default.yaml`.

```bash
bash scripts/download_cmapss.sh   # download and extract
```

---

## ▶️ Usage

**Reproduce one task (e.g., Task B domain shift)**

```bash
python src/fedtide/train.py --task B --config config/default.yaml
```

**All five tasks**

```bash
for t in A B C D E; do bash scripts/run_task.sh $t; done
```

**Ablation (disable one component)**

```bash
python src/fedtide/train.py --task D --ablate no_tpa   # or no_des / no_gate
```

---

## 🔧 Key Hyperparameters (`config/default.yaml`)

| Parameter | Meaning | Default |
|---|---|---|
| `lora.rank` | LoRA rank r | 8 |
| `tpa.alpha` | data-volume exponent n^α | 0.5 |
| `tpa.tau` | MMD temperature | 1.0 |
| `tpa.rho` | freshness decay ρ | 0.9 |
| `des.kappa` | drift evidence budget κ | tune |
| `des.t_max` | max staleness (force aggregation) | tune |
| `des.t_q` | quarantine threshold (rounds) | tune |
| `des.local_steps` | local adaptation steps E on alarm | 5 |
| `fuse.eta` | fusion step size η | 1.0 |
| `fuse.rank` | projection rank r (= LoRA rank) | 8 |

---

## 📖 Citation

```bibtex
@inproceedings{zhao2026fedtide,
  title   = {{FedTIDE}: Federated Adaptation of Time-Series Foundation Models
             under Spatio-Temporal Drift},
  author  = {Zhao, Zhigang and Li, Chuantao and Huo, Jidong and
             Wang, Chunxiao and Gao, Longxiang},
  booktitle = {IEEE International Conference on Acoustics, Speech and
               Signal Processing (ICASSP)},
  year    = {2027}
}
```

---

## 📄 License

MIT License. See `LICENSE` for details.

## 🙏 Acknowledgements

We build on [Chronos-2](https://github.com/amazon-science/chronos-forecasting), [FedCMAPSS](https://github.com/perceivelab/FedCMAPSS), and the LoRA / ADWIN / MMD lines of work.
