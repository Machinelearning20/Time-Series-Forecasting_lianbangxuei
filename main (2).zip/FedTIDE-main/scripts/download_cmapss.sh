#!/usr/bin/env bash
# 下载并解压 NASA C-MAPSS 数据（FD001–FD004）
set -euo pipefail

DATA_DIR="${1:-data}"
mkdir -p "$DATA_DIR"

# NASA PCoE 数据仓库的 C-MAPSS zip（若链接失效请到官网手动下载）
URL="https://ti.arc.nasa.gov/m/project/prognostic-repository/CMAPSSData.zip"
ZIP="$DATA_DIR/CMAPSSData.zip"

if [ ! -f "$ZIP" ]; then
  echo "⬇️  下载 C-MAPSS ..."
  curl -L -o "$ZIP" "$URL" || echo "⚠️  自动下载失败，请从 NASA PCoE 官网手动下载到 $DATA_DIR"
fi

if [ -f "$ZIP" ] && [ ! -d "$DATA_DIR/CMAPSSData" ]; then
  echo "📦 解压 ..."
  unzip -q "$ZIP" -d "$DATA_DIR" || true
fi

echo "✅ 完成。请在 config/default.yaml 里确认 data.cmapss_dir=$DATA_DIR/CMAPSSData"
