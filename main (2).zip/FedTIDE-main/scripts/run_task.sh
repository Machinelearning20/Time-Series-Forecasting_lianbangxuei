#!/usr/bin/env bash
# 复现单个 task（A-E）
set -euo pipefail
TASK="${1:-B}"
CONFIG="${2:-config/default.yaml}"

echo "🚀 运行 FedTIDE Task $TASK"
python src/fedtide/train.py --task "$TASK" --config "$CONFIG"
