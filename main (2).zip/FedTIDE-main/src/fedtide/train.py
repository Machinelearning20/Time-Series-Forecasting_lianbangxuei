"""训练/评测主入口：静态 FedCMAPSS 协议。

用法:
    python src/fedtide/train.py --task B --config config/default.yaml
    python src/fedtide/train.py --task D --ablate no_tpa

流程: 加载数据 → FedCMAPSS 划分 → 初始化 Server/Clients → 联邦循环
      → 末轮评测 RMSE + NASA Score。
"""
from __future__ import annotations

import argparse
import yaml


def parse_args():
    p = argparse.ArgumentParser(description="FedTIDE")
    p.add_argument("--task", choices=list("ABCDE"), required=True)
    p.add_argument("--config", default="config/default.yaml")
    p.add_argument("--ablate", choices=["no_tpa", "no_des", "no_gate"], default=None)
    p.add_argument("--device", default="auto")
    return p.parse_args()


def main():
    args = parse_args()
    cfg = yaml.safe_load(open(args.config))
    # TODO:
    #  1) data.load_cmapss + window_trajectories + fedcmapss_partition(task)
    #  2) model.FedTIDEModel(chronos-2, lora_rank=cfg.lora.rank)
    #  3) 若 --ablate 则关闭对应组件（no_tpa -> 样本量加权；no_des -> 固定轮次）
    #  4) 联邦循环：Server.step / Client.report，统计 events 数
    #  5) 评测 metrics.rmse / metrics.nasa_score_scaled，打印 Table 格式
    raise NotImplementedError


if __name__ == "__main__":
    main()
