"""冻结 Chronos-2 编码器 + MLP 回归头（标量 RUL）。

对应手稿 §4.1 "Backbone and adapter"。
channel-independent tokenization 吸收跨客户端异构的通道数 C_k；
head g_ψ 把 backbone 表示映射到标量 RUL。
"""
from __future__ import annotations

import torch
from torch import nn


class FrozenChronos2Encoder(nn.Module):
    """加载 Chronos-2 预训练权重并冻结，作为时序编码器。

    Returns:
        patch_prototypes: [B, n_patches, d] 均值池化前的 patch 嵌入（供签名/漂移检测用）
        pooled:           [B, d] 均值池化原型（供回归头用）
    """
    def __init__(self, hf_id: str, patch_len: int = 16, freeze: bool = True):
        super().__init__()
        # TODO: 用 transformers 加载 Chronos-2，遍历 attention 层注册 LoRA 钩子点。
        raise NotImplementedError

    def forward(self, x: torch.Tensor):
        raise NotImplementedError


class RULHead(nn.Module):
    """轻量 MLP 回归头：pooled 表示 -> 标量 RUL。"""
    def __init__(self, d_model: int, hidden: int = 128):
        super().__init__()
        self.mlp = nn.Sequential(
            nn.Linear(d_model, hidden), nn.GELU(), nn.Linear(hidden, 1)
        )

    def forward(self, h: torch.Tensor) -> torch.Tensor:
        return self.mlp(h).squeeze(-1)  # [B]


class FedTIDEModel(nn.Module):
    """FedTIDE 完整模型 = FrozenChronos2Encoder + LoRA + RULHead。

    注意：LoRA 的 A/B 参数与 head 是唯一可训练部分；backbone 权重冻结。
    """
    def __init__(self, hf_id: str, lora_rank: int = 8, patch_len: int = 16):
        super().__init__()
        self.encoder = FrozenChronos2Encoder(hf_id, patch_len=patch_len, freeze=True)
        self.head = RULHead(d_model=self.encoder.d_model)
        # TODO: self.lora = inject_lora(self.encoder, rank=lora_rank)

    def forward(self, x: torch.Tensor):
        _, pooled = self.encoder(x)
        return self.head(pooled)
