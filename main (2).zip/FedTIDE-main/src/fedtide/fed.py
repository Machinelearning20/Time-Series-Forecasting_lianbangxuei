"""FedTIDE 联邦双时间尺度闭环：Client + Server。

快尺度（Client）：流式 → 漂移监测 → 报警后 E 步局部适应 → 上传 (Δ_k, s_k, m_k)。
慢尺度（Server）：维护共识签名 s̄；触发 Eq(4) 后选参与集、TPA 加权、product 融合、广播。
"""
from __future__ import annotations

from dataclasses import dataclass, field

from . import tpa, des, lora


@dataclass
class ClientReport:
    client_id: int
    lora_delta: dict          # 局部 LoRA 增量（product 空间）
    signature: object         # 时序签名 s_k
    drift_magnitude: float    # 漂移量级 m_k
    alarm: bool               # a_k


class Client:
    """单客户端：本地数据 + 局部适应 + 漂移监测。"""
    def __init__(self, client_id: int, model, dataloader, cfg):
        self.client_id = client_id
        self.model = model
        self.dataloader = dataloader
        self.cfg = cfg
        self.adwin = des.ADWIN(cfg.des.delta)
        self.stale_rounds = 0

    def local_adapt(self, steps: int) -> None:
        """报警后对最近 buffer 做 E 步 RUL 回归损失更新（adapter + head 联合）。"""
        raise NotImplementedError

    def monitor(self, x) -> tuple[bool, float]:
        """用冻结 backbone 信号做漂移检测，返回 (alarm, magnitude)。"""
        raise NotImplementedError

    def report(self) -> ClientReport:
        raise NotImplementedError


class Server:
    """服务器：共识签名、TPA 权重、事件触发、product 融合。"""
    def __init__(self, cfg):
        self.consensus_signature = None       # s̄
        self.prev_fusion_direction = None     # Δ̄^{t-1}
        self.round = 0

    def update_consensus(self, reports: list[ClientReport]) -> None:
        """s̄^t = Σ_k ŵ_k^{t-1} s_k^t（上一轮权重重新归一化）。"""
        raise NotImplementedError

    def compute_weights(self, reports: list[ClientReport]) -> dict[int, float]:
        """Eq(3) 四因子权重并归一化。"""
        raise NotImplementedError

    def aggregate(self, reports: list[ClientReport], weights: dict[int, float]):
        """product-space 融合 + 截断 SVD 回秩 + 广播全局 adapter。"""
        raise NotImplementedError

    def step(self, reports: list[ClientReport]) -> bool:
        """一轮服务器逻辑：更新共识 → 若触发则聚合并返回 True。"""
        raise NotImplementedError
