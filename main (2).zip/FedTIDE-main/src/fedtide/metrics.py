"""评测指标：RMSE + NASA Score（PHM 标准，非对称罚分）。

对应手稿 §4.1 "Metrics"：
    S = Σ_i s_i,  s_i = exp(-Δ_i/13)-1 (Δ_i<0),  exp(Δ_i/10)-1 (Δ_i>=0),  Δ_i = ŷ_i - y_i
晚预测（高估 RUL）罚得更重。
"""
from __future__ import annotations

import numpy as np


def rmse(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    return float(np.sqrt(np.mean((np.asarray(y_true) - np.asarray(y_pred)) ** 2)))


def nasa_score(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """返回原始 NASA score S（投稿表格需除以 1000 以对齐 FedCMAPSS 口径）。"""
    d = np.asarray(y_pred) - np.asarray(y_true)
    s = np.where(d < 0, np.exp(-d / 13.0) - 1.0, np.exp(d / 10.0) - 1.0)
    return float(s.sum())


def nasa_score_scaled(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """NASA Score ×10⁻³（与论文表同量纲）。"""
    return nasa_score(y_true, y_pred) / 1000.0
