"""LoRA 注入与 product-space 融合（截断 SVD 回秩）。

对应手稿 §3.2 "Product-space fusion"。
动机：分别平均 LoRA 因子 (A 平均、B 平均) 会引入失真（FedEx-LoRA 指出），
故在 B·A 乘积空间加权融合，再截断 SVD 回秩 r。
"""
from __future__ import annotations

import torch
from torch import nn


class LoRALinear(nn.Module):
    """LoRA 适配的线性层：W = W0 + B A。"""
    def __init__(self, base: nn.Linear, rank: int, alpha: float = 16.0):
        super().__init__()
        self.base = base            # 冻结
        self.rank = rank
        self.scale = alpha / rank
        # TODO: A: [in, r] 高斯初始化；B: [r, out] 零初始化。
        raise NotImplementedError

    def forward(self, x):
        return self.base(x) + (x @ self.A @ self.B) * self.scale


def inject_lora(model: nn.Module, rank: int, target_modules=("q_proj", "v_proj")) -> nn.Module:
    """把 LoRA 注入 backbone 指定注意力投影层，返回可训练参数 dict。"""
    raise NotImplementedError


def get_lora_delta(model) -> dict[str, torch.Tensor]:
    """导出每个 LoRA 模块的增量 Δ = B A（product 空间，未加 scale）。"""
    raise NotImplementedError


def set_lora_product(model, products: dict[str, torch.Tensor]) -> None:
    """从 product 空间回写 LoRA 因子（truncated SVD: P -> (B, A)）。"""
    raise NotImplementedError


def product_fuse(global_products, client_products, weights, eta=1.0):
    """product-space 加权融合。

    Args:
        global_products: {module_name: P^g}
        client_products:  [{module_name: P_k}]
        weights:          归一化后的 TPA 权重 ŵ_k
        eta:              融合步长 η
    Returns:
        融合后的 product（随后调用 set_lora_product 回写并做截断 SVD）
    """
    raise NotImplementedError
