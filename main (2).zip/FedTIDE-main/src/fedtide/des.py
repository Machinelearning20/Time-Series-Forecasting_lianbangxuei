"""DES：ADWIN/MMD 漂移检测 + 事件触发 + 陈旧客户端隔离。

对应手稿 §3.3 与服务器触发 Eq(4)：
    u^t = 1{ Σ_k m_k^t a_k^t >= κ  OR  max_k Δt_k >= T_max }
参与集 S^t = {k : a_k^t = 1}；沉默超过 T_q 轮隔离。
"""
from __future__ import annotations

import numpy as np
from dataclasses import dataclass


@dataclass
class DriftSignal:
    """冻结 backbone 导出的模型无关漂移信号流。"""
    residual: float           # 一步预测残差 |y - ŷ|
    embed_stat: float         # 嵌入原型位移 / 频谱带能量变化量


class ADWIN:
    """自适应滑动窗口（SDM'07），内联实现，无外部依赖。"""
    def __init__(self, delta: float = 0.002):
        # TODO: 维护分桶窗口，加元素时检测子窗口均值差是否超阈值。
        raise NotImplementedError

    def add(self, val: float) -> bool:
        """加入一个值，返回是否检测到漂移。"""
        raise NotImplementedError


def detect_drift(signals: list[DriftSignal], detector: str = "adwin",
                 mmd_ref_window=None) -> tuple[bool, float]:
    """在两条信号流上检测漂移，返回 (alarm a_k, 漂移量级 m_k)。

    detector: 'adwin' | 'mmd' | 'both'
    m_k: 由 ADWIN 触发幅度或 MMD 两样本检验统计量估计。
    """
    raise NotImplementedError


def server_trigger(evidence: list[float], staleness: dict[int, int],
                   kappa: float, t_max: int) -> bool:
    """服务器端聚合触发 Eq(4)。"""
    # TODO: 累积证据 Σ m_k a_k 与 κ 比较；或 max Δt_k >= T_max。
    raise NotImplementedError


def select_participants(alarms: dict[int, bool], stale_rounds: dict[int, int],
                        t_q: int) -> list[int]:
    """参与集 S^t = {k: a_k=1}；沉默 > T_q 轮隔离。"""
    raise NotImplementedError
