"""FedTIDE: Federated Adaptation of Time-Series Foundation Models under Spatio-Temporal Drift.

Subpackages:
    data      — C-MAPSS loading, windowing, RUL labeling, FedCMAPSS 5-task partitioning
    model     — frozen Chronos-2 encoder + MLP RUL head
    lora      — LoRA A/B injection + product-space fusion (truncated SVD)
    tpa       — temporal signature + MMD + 4-factor weighting
    des       — ADWIN/MMD drift detection + event triggering + quarantine
    fed       — Client/Server dual time-scale loop
    metrics   — RMSE + NASA score
"""

__version__ = "0.1.0"
